#!/bin/bash

#wget http://snap.stanford.edu/data/amazon/productGraph/categoryFiles/reviews_Books_5.json.gz


# decompress and remove compressed.
# gzip -d reviews_Books_5.json.gz 

